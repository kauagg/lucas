class SmartDevice {
  SmartDevice({required this.isOn, required this.value});

  final bool isOn;
  final int value;
}
